# 🎯 REVISED TIER 1 QUALIFICATION CRITERIA

## Your Actual ICP Definition

**TIER 1 = ALL 6 criteria must be met:**

1. ✅ **Series A or B** (NOT Seed, NOT Series C+)
2. ✅ **$5M-$30M ARR range**
3. ✅ **50-300 employees**
4. ✅ **Posted RevOps OR Sales Ops role in last 90 days**
5. ✅ **Using ZoomInfo OR Apollo OR Clay** (data sophistication signal)
6. ✅ **One trigger:**
   - Recent funding (last 6 months)
   - Compliance deadline (SOC 2, ISO, GDPR)
   - New CRO/VP Sales hire
   - Geographic expansion

**TIER 2 = Missing 1-2 criteria** (still qualified, lower priority)

**TIER 3 = Interesting but wrong timing** (future pipeline)

---

## 🔴 RE-EVALUATION: Previous "HOT" Leads

### **HARNESS - Now TIER 3 (Not Tier 1)**
- ❌ Series E (not A/B)
- ❌ >$30M ARR
- ❌ >300 employees
- ✅ Posted VP RevOps role
- ❓ Unknown tech stack
- ✅ Recent $240M raise

**Result: TIER 3** - Wrong stage (too mature for RevPartners ICP)

---

### **TEBRA - Now TIER 3 (Not Tier 1)**
- ❌ Late stage ($250M raised)
- ❌ >$30M ARR
- ❌ >300 employees
- ✅ Posted Revenue Ops Manager
- ❓ Unknown tech stack
- ❌ No recent funding

**Result: TIER 3** - Wrong stage (too mature)

---

### **CYERA - Now TIER 3 (Not Tier 1)**
- ❌ Series C/D ($400M raise)
- ❌ >$30M ARR
- ❌ >300 employees
- ✅ Posted Sales Ops roles
- ❓ Unknown tech stack
- ✅ Recent $400M raise

**Result: TIER 3** - Wrong stage (post-unicorn)

---

## ✅ NEW APPROACH: Finding TRUE Tier 1 Companies

### **Step 1: Filter Original 105 Companies by Stage**

From your Funding CSV, Series A/B companies:

| Company | Funding Stage | Estimated ARR | Match Criteria 1-3? |
|---------|--------------|---------------|---------------------|
| **InsightX** | Series A ($600M likely $60M) | $10-15M | ✅ Need employee count |
| **Double** | Series A ($6.5M) | $2-5M | ⚠️ Below $5M ARR threshold |
| **On Me** | Series A ($6M) | $3-8M | ⚠️ Need employee validation |
| **Revibe** | Series A ($17M) | $8-15M | ✅ Likely match |
| **Saladin** | Series A | $5-12M | ✅ Likely match |
| **Verisoul** | Series A ($8.8M) | $3-8M | ⚠️ Need employee validation |
| **Fluency** | Series A ($40M) | $10-20M | ✅ Likely match |
| **Echo** | Series A ($35M) | $12-25M | ✅ Likely match |
| **Ankar** | Series A ($20M) | $8-18M | ✅ Likely match |
| **Roamless** | Series A ($12M) | $5-12M | ✅ Likely match |

**Series B Companies (also qualify):**
- Need to search the CSV for Series B mentions

---

### **Step 2: Check Employee Count (50-300)**

**How to verify:**
- LinkedIn company page shows employee count
- Crunchbase shows employee range
- Check "About" page on their website

**Action needed:** Batch check these 10 companies

---

### **Step 3: Check Tech Stack (ZoomInfo/Apollo/Clay)**

**How to verify:**
1. **BuiltWith.com** - Shows tech stack
2. **LinkedIn Sales Navigator** - Check if using ZoomInfo/Apollo enrichment
3. **Job postings** - Often mention tools ("experience with Apollo.io required")
4. **Check for signals:**
   - Job posting mentions "ZoomInfo experience"
   - SDR job posts mention "Apollo" or "Clay"
   - LinkedIn profiles show "uses Apollo.io"

**Action needed:** Check BuiltWith for each company

---

### **Step 4: Look for GTM Job Postings (Last 90 Days)**

**Search for each Series A/B company:**
```
site:linkedin.com/jobs [Company] ("Revenue Operations" OR "Sales Operations" OR "Marketing Operations")
```

**Filter by Date Posted:** Last 3 months

---

### **Step 5: Check for Triggers**

**For each company passing Steps 1-4, check:**

**A) Recent Funding (Last 6 months):**
- Check Crunchbase "Funding Rounds" - filter by 2025
- Check TechCrunch, The SaaS News for announcements

**B) New CRO/VP Sales Hire:**
- LinkedIn search: `[Company] AND ("Chief Revenue Officer" OR "CRO" OR "VP Sales") AND "Started new position"`
- Filter: Past 6 months

**C) Geographic Expansion:**
- Job postings in new regions
- Press releases about "expanding to EMEA" or "opening Austin office"
- LinkedIn posts from leadership about expansion

**D) Compliance Deadline:**
- Check website for "SOC 2 certified" or "in progress"
- Look for security/compliance job postings
- Search news for "[Company] SOC 2" or "[Company] compliance"

---

## 🚀 REVISED WORKFLOW

### **Phase 1: Pre-Qualify (Do This First)**

For each of the 10 Series A/B companies above:

1. **LinkedIn Company Page** → Get employee count
2. **BuiltWith.com** → Check if using ZoomInfo/Apollo/Clay
3. **Crunchbase** → Confirm ARR range estimate
4. **LinkedIn Jobs Search** → Check for RevOps/Sales Ops posting

**Result:** List of companies meeting criteria 1-4

---

### **Phase 2: Find Triggers (Only for Pre-Qualified)**

For companies passing Phase 1:

5. **Check Crunchbase** → Recent funding (2025/late 2024)
6. **LinkedIn People Search** → New CRO/VP Sales (last 6 months)
7. **Google News Search** → "[Company] expansion" OR "[Company] SOC 2"
8. **Company Blog/LinkedIn** → Geographic expansion announcements

**Result:** List of TRUE TIER 1 companies (all 6 criteria met)

---

### **Phase 3: Deep Research (Only Tier 1)**

For confirmed Tier 1 companies:

9. **Generate full playbook** (GTM Context Engine)
10. **Find 3 contacts** (Head of Growth, VP RevOps, CRO)
11. **Craft personalized outreach** (reference specific trigger)

---

## 📊 Expected Results with Strict Criteria

From 105 original companies:
- **Series A/B:** ~15-20 companies (15-20%)
- **Meet ARR + employee count:** ~10-12 companies (10-12%)
- **Using ZoomInfo/Apollo/Clay:** ~5-7 companies (5-7%)
- **Posted GTM role in 90 days:** ~2-3 companies (2-3%)
- **Have additional trigger:** ~1-2 companies (1-2%)

**Expected TRUE TIER 1 leads: 1-2 companies**

This is much more targeted than my previous "HOT" leads approach.

---

## 🎯 Action Plan

**Option A: I Do Manual Pre-Qualification**
- I check LinkedIn, BuiltWith, Crunchbase for top 10 Series A/B companies
- Filter down to TRUE Tier 1 (may be 0-2 companies)
- Generate deep playbooks only for confirmed Tier 1

**Option B: You Provide Access to Tools**
- If you have ZoomInfo/Apollo access, you can filter faster
- Export: Series A/B, 50-300 employees, using Apollo/ZoomInfo
- I focus on job posting + trigger verification

**Option C: Hybrid Approach**
- You tell me which companies from the list are definitely Series A/B in your target range
- I verify job postings + triggers + tech stack
- We focus only on confirmed matches

**Which approach works best?**

---

## 💡 Why This Is Better

**OLD approach (my previous analysis):**
- Found 3 companies with GTM job postings
- But all were Series E / Late-stage (wrong ICP)
- Would waste time on companies too mature for RevPartners

**NEW approach (your criteria):**
- Hyper-targeted Series A/B scaling companies
- All 6 criteria = high intent + perfect fit
- May find fewer leads, but each is a perfect ICP match
- Higher close rate (50%+) because fit is perfect

**Quality over quantity.**
