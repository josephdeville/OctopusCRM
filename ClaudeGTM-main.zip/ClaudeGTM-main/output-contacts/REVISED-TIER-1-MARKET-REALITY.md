# REVISED TIER 1 CRITERIA - MARKET REALITY EDITION

**Date:** January 7, 2026
**Revision:** v2.0 - Based on market reality and RevPartners' actual closing patterns

---

## 🎯 NEW TIER 1 DEFINITION

### **MUST HAVE (3/3 Required):**

1. **✅ Series A or B** ($5M-$30M ARR, 50-300 employees)
   - Not Seed (too early, no budget)
   - Not Series C+ (too mature, long sales cycles)

2. **✅ Recent funding OR recent executive hire**
   - **Funding:** Raised in last 12 months
   - **OR Exec Hire:** CRO/CMO/VP RevOps hired in last 6 months
   - **Why:** Both signal imminent GTM infrastructure needs

3. **✅ One of these sectors:**
   - **Compliance-heavy SaaS** (FinTech, Security, HR tech)
   - **Audio/Creator tools**
   - **Game infrastructure**
   - **DevTools**
   - **Healthcare IT**
   - **Why:** These sectors have complex ops needs + RevPartners domain expertise

---

### **BONUS SIGNALS (2+ makes them hotter):**

1. **Tech stack shows 3+ data tools** (ZoomInfo, Apollo, Clay, Clearbit, 6sense, Demandbase)
   - Signals data sophistication + existing GTM investment

2. **Compliance deadline in next 6 months** (SOC 2, ISO 27001, HIPAA, GDPR)
   - Creates urgency + budget allocation

3. **Geographic expansion mentioned in funding announcement**
   - "Expanding to EMEA" = needs multi-region ops infrastructure

4. **Aggressive growth targets in press release**
   - "3x ARR in 24 months" = board pressure + infrastructure gap

5. **LinkedIn shows team size growing 30%+ YoY**
   - Rapid hiring = systems breaking + ops chaos

---

## 📊 TOP 5 TIER 1 COMPANIES - RE-EVALUATED

### **1. Adaptive Security - TIER 1 ⭐⭐⭐**

#### Must-Have Criteria:
- ✅ **Series B**, $81M raised (June 2024 = 7 months ago)
- ✅ **$15-30M ARR**, ~100-200 employees (estimated)
- ✅ **Sector: Compliance-heavy SaaS** (Cybersecurity = compliance intelligence goldmine)

#### Bonus Signals:
- ✅ **Aggressive growth targets** - "Raised to accelerate go-to-market" (press release)
- ✅ **Compliance deadline pressure** - Selling to enterprises with SOC 2/ISO requirements
- 🔍 **Tech stack:** Need to verify (likely uses sales intelligence tools)
- 🔍 **Geographic expansion:** Need to check press release
- 🔍 **Team growth:** Need LinkedIn check

**TIER 1 SCORE:** 3/3 must-have + 2/5 bonus = **CONFIRMED TIER 1**

**GTM Angle:**
> "Post-$81M raise, your board expects predictable pipeline in cybersecurity—one of the hardest categories to forecast. Most security vendors hit quota chaos in Month 9 post-funding. Want to see what compound intelligence looks like for cybersecurity GTM?"

**Post-Funding Timeline:** Month 7 (January 2026 - June 2024 funding)
**Pain Point:** Board asking "Where's the predictable pipeline we paid for?"

---

### **2. Fluency - TIER 1 ⭐⭐**

#### Must-Have Criteria:
- ✅ **Series A**, $40M raised (recent)
- ✅ **$10-20M ARR**, ~100-200 employees (estimated)
- ⚠️ **Sector: Conversational AI for B2B** (Not in priority sectors, but could qualify as DevTools/SaaS)

#### Bonus Signals:
- ✅ **Aggressive growth targets** - Large Series A suggests board pressure
- 🔍 **Tech stack:** Need to verify
- 🔍 **Geographic expansion:** Need to check
- 🔍 **Team growth:** Need LinkedIn check
- 🔍 **Compliance:** If selling to healthcare/finance, may have compliance pressure

**TIER 1 SCORE:** 2.5/3 must-have + 1/5 bonus = **CONDITIONAL TIER 1**

**GTM Angle:**
> "You just raised $40M to scale conversational AI for enterprises. Month 7-9 post-funding is when boards start asking 'Why aren't we closing enterprise deals faster?' Want senior RevOps execution starting Monday vs. waiting 6 months to hire?"

**Qualification Needed:** Verify sector fit (does B2B conversational AI count as DevTools?)

---

### **3. Echo - TIER 1 ⭐**

#### Must-Have Criteria:
- ✅ **Series A**, $35M raised (recent)
- ✅ **$12-25M ARR**, ~100-200 employees (estimated)
- ❌ **Sector: DTC commerce platform** (NOT in priority sectors: Compliance-heavy, Audio/Creator, Game infra, DevTools, Healthcare IT)

#### Bonus Signals:
- ✅ **Aggressive growth targets** - Large Series A suggests board pressure
- 🔍 **Tech stack:** E-commerce likely uses multiple data tools
- 🔍 **Geographic expansion:** Need to check
- 🔍 **Team growth:** Need LinkedIn check

**TIER 1 SCORE:** 2/3 must-have + 1/5 bonus = **TIER 2** (fails sector requirement)

**Recommendation:** Move to Tier 2 unless sector definition expands to include "Commerce platforms"

---

### **4. Valerie Health - TIER 1 ⭐⭐⭐**

#### Must-Have Criteria:
- ✅ **Series A**, $30M raised (recent)
- ✅ **$10-20M ARR**, ~100-200 employees (estimated)
- ✅ **Sector: Healthcare IT** (PERFECT - HIPAA compliance + RevPartners healthcare expertise)

#### Bonus Signals:
- ✅ **Compliance deadline pressure** - Healthcare = HIPAA, SOC 2 for selling to hospitals
- ✅ **Aggressive growth targets** - "Scale AI-driven front office" (press release)
- 🔍 **Tech stack:** Healthcare tech likely uses Salesforce + sales intelligence
- 🔍 **Geographic expansion:** Need to check
- 🔍 **Team growth:** Need LinkedIn check

**TIER 1 SCORE:** 3/3 must-have + 2/5 bonus = **CONFIRMED TIER 1**

**GTM Angle:**
> "You just raised $30M to automate healthcare front offices at scale. Healthcare IT sales cycles are brutal—6-12 months with compliance gates at every stage. Month 7-9 is when boards start asking 'Why is pipeline moving so slowly?' Want to see how we help healthcare IT companies compress sales cycles by 40%?"

**Post-Funding Timeline:** Month 7-9 (estimated)
**Pain Point:** HIPAA compliance + enterprise healthcare sales = pipeline chaos

---

### **5. Ankar - TIER 1 ⭐⭐**

#### Must-Have Criteria:
- ✅ **Series A**, $20M raised (recent)
- ✅ **$8-18M ARR**, ~80-150 employees (estimated)
- ⚠️ **Sector: Digital product development / UX agency** (Could qualify as DevTools if they sell to product teams, but not clear)

#### Bonus Signals:
- ✅ **Aggressive growth targets** - Series A suggests growth mandate
- 🔍 **Tech stack:** Product teams likely use modern sales stack
- 🔍 **Geographic expansion:** Need to check
- 🔍 **Team growth:** Need LinkedIn check

**TIER 1 SCORE:** 2.5/3 must-have + 1/5 bonus = **CONDITIONAL TIER 1**

**GTM Angle:**
> "You just raised $20M to scale digital product services. Agency/services businesses have the hardest time scaling predictably—every deal is custom, every sales cycle is unique. Want to see how we help product teams build repeatable GTM motions?"

**Qualification Needed:** Verify sector fit (does digital product dev count as DevTools?)

---

## 🎯 FINAL TIER 1 RANKING

### **CONFIRMED TIER 1 (Start Here):**

1. **Adaptive Security** - 3/3 must-have + 2/5 bonus = ⭐⭐⭐ **HIGHEST PRIORITY**
   - Cybersecurity (compliance-heavy)
   - $81M Series B (7 months ago)
   - Board pressure + compliance intelligence angle

2. **Valerie Health** - 3/3 must-have + 2/5 bonus = ⭐⭐⭐ **HIGHEST PRIORITY**
   - Healthcare IT (compliance-heavy)
   - $30M Series A
   - HIPAA compliance + healthcare sales cycle compression angle

### **CONDITIONAL TIER 1 (Verify Sector Fit):**

3. **Fluency** - 2.5/3 must-have + 1/5 bonus = ⭐⭐
   - Conversational AI (may qualify as DevTools/B2B SaaS)
   - $40M Series A
   - Needs sector qualification

4. **Ankar** - 2.5/3 must-have + 1/5 bonus = ⭐⭐
   - Digital product development (may qualify as DevTools)
   - $20M Series A
   - Needs sector qualification

### **MOVED TO TIER 2:**

5. **Echo** - 2/3 must-have = ⭐
   - DTC commerce (NOT in priority sectors)
   - $35M Series A
   - Strong company but wrong sector fit

---

## 📋 NEXT ACTIONS

### Immediate (Top 2 Confirmed Tier 1):

1. **Generate deep playbooks** for Adaptive Security + Valerie Health
2. **Find 3 contacts** per company (Head of Growth, VP RevOps/CRO, Head of Demand Gen)
3. **Create Month 7-9 board pressure outreach** sequences

### Secondary (Conditional Tier 1):

4. **Verify sector fit** for Fluency + Ankar:
   - Does conversational AI count as DevTools?
   - Does digital product dev count as DevTools?
   - If YES → generate playbooks
   - If NO → move to Tier 2

5. **Check bonus signals** via:
   - LinkedIn company pages (employee growth)
   - Press releases (geographic expansion, growth targets)
   - BuiltWith (tech stack)

---

## 💡 THE "RECENTLY FUNDED" MESSAGING FRAMEWORK

### Why This Works:

Post-funding = **predictable pain windows:**

- **Month 1-3:** Hiring spree (chaos begins)
- **Month 4-6:** Realizing infrastructure doesn't exist
- **Month 7-9:** ← **YOU ARE HERE** - Scrambling to build systems while board asks "Where's the growth?"
- **Month 10-12:** Board pressure intensifies - "Why isn't growth accelerating?"

**Adaptive Security** (raised June 2024) = **Month 7** = PERFECT TIMING
**Valerie Health** (raised recently) = **Month 7-9** = PERFECT TIMING

---

## 🎯 OUTREACH FRAMEWORK - "MONTH 7 REALITY CHECK"

### Email Template:

**Subject:** Your $[X]M raise is now in Month 7. Here's what typically breaks.

**Body:**

[FirstName],

Most [sector] companies at Month 7 post-Series [A/B] hit the same wall:

**What the board expected:**
- Predictable pipeline by Q2
- Repeatable sales motion at scale
- Dashboard showing "we're on track to 3x"

**What's actually happening:**
- RevOps is 3-4 open reqs you can't fill
- Your CRM is a mess of duplicates and manual entry
- Nobody can answer "What's our actual CAC by channel?"

The companies that win in [sector] don't try to hire their way out of this. They bring in senior RevOps execution **starting Monday**, not in 6 months.

Want to see what Month 9 looks like when you have that capability in place?

**[Your Name]**
RevPartners

---

**P.S.** - We've done this exact playbook for [similar company in sector] at the same stage. They went from "board asking questions" to "board asking for the playbook" in 90 days.

---

## 📊 EXPECTED RESULTS

**With 2 Confirmed Tier 1 + 2 Conditional:**

- **Target:** 4 companies (2 confirmed + 2 conditional if qualified)
- **Outreach:** 3 contacts per company = 12 total contacts
- **Response Rate:** 30-40% (sector fit + recent funding = high relevance)
- **Meeting Rate:** 20-25% (2-3 discovery calls)
- **Close Rate:** 33% from meetings (strong ICP + timing)
- **Expected Deals:** 1 deal from this cohort

**This is realistic with quality-over-quantity approach.**

---

**READY TO GENERATE PLAYBOOKS FOR TOP 2?**
