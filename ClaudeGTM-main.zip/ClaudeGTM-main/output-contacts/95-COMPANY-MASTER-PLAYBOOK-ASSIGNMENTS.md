# 95 COMPANY MASTER LIST - PLAYBOOK ASSIGNMENT & OUTREACH

**Total Companies:** 95 (filtered from 105)
**Removed:** 10 (government entities, non-profits, public companies, duplicates)
**Output:** Playbook assignment + personalized outreach reasoning for each

---

## COMPANIES REMOVED (10)

1. **SUNY** - Public university (government entity)
2. **Google** - Public company (too large)
3. **Katonah American Legion Post** - Non-profit
4. **EPA** - Government agency
5. **Welsh Government** - Government entity
6. **DHS** - Department of Homeland Security (government)
7. **NuclearStartupLast** - Duplicate entry (empty row)
8. **Pillen** - Government funding announcement (not B2B SaaS)
9. **NYS Insurance Fund** - State government insurance fund
10. **ABC15 Arizona** - Local media/broadcasting (not SaaS)

---

## 95 COMPANIES - PLAYBOOK ASSIGNMENTS

### BATCH 1: COMPANIES 1-20

| # | Company | Funding | ARR Est. | Playbook Type | Why This Playbook | Outreach Hook |
|---|---------|---------|----------|---------------|-------------------|---------------|
| 1 | **NXXIM** | Seed | $2-5M | Practitioner - Head of Growth | Early-stage growth marketing/A/B testing platform needs growth playbook for rapid user acquisition | "You're building an A/B testing platform - which means you understand data-driven growth. But are you applying that same rigor to YOUR OWN GTM motion? Most growth platforms have messy attribution and can't explain their own CAC by channel." |
| 2 | **Harness** | Series E | $50M+ | TIER 3 - Too Mature | Late-stage DevOps, too mature for RevPartners ICP | Skip - Series E |
| 3 | **InsightX** | Series A | $10-15M | Milestone - Series A Scaling | B2B analytics platform at $10-15M ARR needs RevOps infrastructure to scale from early traction to repeatable motion | "You help companies centralize analytics to drive growth. But at $10-15M ARR, who's centralizing YOUR revenue data? Most analytics companies have blind spots in their own pipeline visibility because they're too close to the product." |
| 4 | **Double** | Series A | $2-5M | Practitioner - Head of Ops | Virtual assistant platform needs operations playbook for scaling executive support services | "You provide executive assistants to help founders scale. But who's providing the RevOps support to help YOU scale? At $6.5M Series A, you need someone managing your GTM operations the way your EAs manage executive operations." |
| 5 | **LI.FI** | Series A | $8-15M | Sector - Web3/Crypto | Crypto infrastructure needs specialized crypto GTM playbook (complex enterprise partnerships) | "You're aggregating bridges and DEX protocols for crypto. But is anyone aggregating YOUR fragmented GTM data? Web3 companies struggle with traditional CRM - your deals happen in Discord, partnerships close via Twitter DMs, and Salesforce can't track any of it." |
| 6 | **On Me** | Series A | $3-8M | Milestone - Series A Scaling | Digital prepaid/gift card platform scaling to enterprises needs milestone playbook | "You're automating benefits distribution at scale. But at Series A with enterprise customers, who's automating YOUR sales operations? Most platforms selling to HR/procurement teams underestimate how complex those sales cycles become." |
| 7 | **Serval** | Series A | $15-25M | Milestone - Series A/B Scaling | B2B SaaS automation at $15-25M ARR needs RevOps to handle enterprise complexity | "You automate customer-facing workflows. But at $15-25M ARR selling to enterprise SaaS vendors, are your OWN workflows automated? Most automation companies have manual, broken RevOps processes - the cobbler's children have no shoes." |
| 8 | **Cheque-in** | Unclear | $5-10M | Practitioner - Head of Operations | Visitor management/check-in system needs ops playbook for hospitality/events | "You're digitizing front-desk check-ins. But who's checking in on YOUR pipeline health? Hospitality tech companies selling to hotels and venues often have seasonal pipeline swings they can't predict because their ops infrastructure is manual." |
| 9 | **Runware** | Series A | $8-12M | Sector - DevTools | Infrastructure automation for SREs needs DevTools sector playbook | "You automate operational runbooks for DevOps teams. But is YOUR revenue operations running on automated playbooks? DevTools companies often have engineers running sales ops - they can build dashboards but not GTM strategy." |
| 10 | **Eikona** | Seed | $3-8M | Practitioner - Head of Marketing | AI-driven marketing creative needs marketing practitioner playbook for DTC/ecommerce | "You generate personalized marketing creative at scale using AI. But are you generating personalized SALES outreach at scale for your own pipeline? Most martech companies have sophisticated marketing ops but broken sales ops." |
| 11 | **Solon Biotech** | Series A | $8-15M | Sector - Life Sciences | Biotech services company needs specialized life sciences GTM playbook (long sales cycles, scientific buyers) | "You provide translational development services to biotech companies. But who's translating YOUR sales data into actionable pipeline insights? Life sciences companies have 12-18 month sales cycles with complex scientific evaluation - traditional RevOps doesn't work." |
| 12 | **Revibe** | Series A | $8-15M | Practitioner - Head of Growth | Re-engagement platform for dormant users needs growth playbook | "You revive dormant customers with automated re-engagement. But how many of YOUR leads go dormant in the pipeline? Most retention/engagement companies have leaky pipelines - they focus on customer LTV but ignore lead nurturing." |
| 13 | **Saladin** | Series A | $5-12M | Milestone - Series A Scaling | AI sales automation needs RevOps to practice what they preach | "You're building AI-driven sales automation. But are you using sophisticated RevOps automation for YOUR OWN sales team? This is the ultimate credibility test - if your sales ops are manual and messy, why would prospects trust your automation?" |
| 14 | **Trendtracker** | Series A | $5-10M | Practitioner - Head of Strategy/Insights | Trend intelligence platform needs insights practitioner playbook | "You provide continuous trend detection for enterprises. But are you continuously monitoring YOUR OWN pipeline trends? Most insights companies have blind spots in their own revenue metrics - they sell data-driven decisions but make GTM decisions on gut feel." |
| 15 | **Sequence** | Series A | Unknown | Milestone - Series A Scaling | AI revenue agents platform needs RevOps (if they can access website) | "Unable to access sequence.com - but if you're building AI revenue agents, the irony would be having broken revenue operations yourself. This is table stakes for credibility in the AI GTM space." |
| 16 | **Valerie Health** | Series A | $10-20M | **TIER 1** - Healthcare IT Compliance | Healthcare AI front office - already have playbook | **ALREADY GENERATED - See TIER1-Valerie-Health-Playbook.md** |
| 17 | **Adaptive Security** | Series B | $15-30M | **TIER 1** - Cybersecurity Series B | Cybersecurity - already have playbook | **ALREADY GENERATED - See TIER1-Adaptive-Security-Playbook.md** |
| 18 | **Smart Joules** | Series B | $8-15M | Sector - Industrial/Energy | Energy optimization needs industrial sector playbook (long enterprise sales, complex ROI) | "You use AI to cut energy costs for manufacturers. But are you cutting waste in YOUR OWN sales process? Industrial/energy companies have 9-12 month sales cycles with complex ROI calculations - you need ops infrastructure that can model and forecast those deals." |
| 19 | **Verisoul** | Series A | $3-8M | Milestone - Series A Scaling | Fraud detection platform needs milestone playbook for high-growth platforms | "You detect fake accounts and fraud in real-time. But can you detect revenue leakage and pipeline fraud in YOUR CRM in real-time? Most security companies have 'commit' forecasts that slip by 40% because they can't see the signals." |
| 20 | **Fluency** | Series A | $10-20M | Milestone - Series A Scaling | Conversational AI for B2B needs scaling playbook | "You automate conversational engagement for enterprises. But at $10-20M ARR with a $40M Series A, who's managing the CONVERSATION between sales, marketing, and revenue operations? Most AI companies have fragmented GTM - marketing says they sourced 60% of pipeline, sales says 20%, and nobody knows the truth." |

---

### BATCH 2: COMPANIES 21-45

| # | Company | Funding | ARR Est. | Playbook Type | Why This Playbook | Outreach Hook |
|---|---------|---------|----------|---------------|-------------------|---------------|
| 21 | **Echo** | Series A | $12-25M | Milestone - Series A/B Scaling | DTC commerce platform at Series A needs scaling playbook for subscription/ecommerce | "You help DTC brands launch stores and sell subscriptions. But at $12-25M ARR, how predictable is YOUR subscription revenue (aka pipeline)? Commerce companies often have great product analytics but terrible sales analytics." |
| 22 | **Logpresso** | Series A | $10-18M | Sector - Security/DevTools | Log analytics for enterprises needs security sector playbook | "You provide real-time log analytics for security teams. But are you analyzing YOUR PIPELINE in real-time? Security vendors have complex evaluation cycles with technical POCs - if you can't forecast when those POCs will convert, your board loses confidence." |
| 23 | **Ankar** | Series A | $8-18M | Practitioner - Head of Product | Digital product development services needs product practitioner playbook | "You help companies accelerate product development. But at Series A, who's accelerating YOUR sales development? Product agencies struggle with productizing their services - every deal feels custom, every sales cycle is unpredictable." |
| 24 | **Magma** | Series A | $8-15M | Sector - DevTools | Managed infrastructure for LLM/vector search needs DevTools playbook | "You provide production-ready infrastructure for AI teams. But is YOUR revenue infrastructure production-ready? DevTools companies often have engineers managing sales ops - great at building systems, terrible at forecasting enterprise deals." |
| 25 | **Roamless** | Series A | $5-12M | Milestone - Series A Scaling | Travel eSIM platform scaling internationally needs geographic expansion playbook | "You're expanding to 200+ countries with eSIM connectivity. But as you expand geographically, how are you managing pipeline across different regions? Travel tech has seasonal swings and regional complexity that breaks simple CRMs." |
| 26 | **Pryzm** | Seed | Unknown | Skip - Insufficient Data | Unable to determine from available info | Skip - no accessible data |
| 27 | **Gambit Cyber** | Seed | $3-5M | Practitioner - Head of Security | Attack simulation for enterprises needs security practitioner playbook | "You validate security controls with automated attack simulation. But can you validate YOUR sales forecast with automated pipeline simulation? Security vendors selling to CISOs have unpredictable evaluation timelines." |
| 28 | **Punto Health** | Seed | $2-5M | Sector - Healthcare IT | Digital patient engagement for health plans needs healthcare sector playbook | "You close care gaps for health plans with digital engagement. But how do you close PIPELINE gaps in your own sales process? Healthcare IT has compliance gates that stall deals for 90+ days - you need ops infrastructure that accounts for that." |
| 29 | **Mirelo** | Seed | $3-8M | Practitioner - Head of Product/Creative | AI-generated audio for video needs creative tech playbook | "You generate synced sound effects and music with AI. But is your GTM hitting the right notes? Media tech companies often have product-led growth motions that mask broken enterprise sales processes." |
| 30 | **Arcads.ai** | Seed | $3-8M | Practitioner - Head of Marketing | AI ad creative for DTC brands needs marketing practitioner playbook | "You automate ad creative generation at scale. But are you automating LEAD generation at scale for your own pipeline? Martech companies typically have sophisticated marketing automation but manual sales processes." |
| 31 | **Lynk** | Pre-Seed | $2-5M | Skip - Too Early | Fitness platform, pre-seed stage | Skip - Pre-seed too early |
| 32 | **BoodleBox** | Seed | $3-8M | Sector - EdTech/Enterprise | Secure AI platform for education/enterprise needs sector playbook | "You provide privacy-respecting AI for institutions. But at Seed stage selling to higher ed and enterprises, how are you managing those 6-12 month evaluation cycles? EdTech has committee-based buying that kills pipeline predictability." |
| 33 | **Dux** | Seed | $5-10M | Sector - Security/DevSecOps | AI-driven vulnerability remediation needs security sector playbook | "You automate vulnerability remediation with AI. But at $9M seed selling to enterprise security teams, can you forecast WHEN deals will remediate (close)? Security vendors often have technical POCs that extend indefinitely." |
| 34 | **Maximum Information** | Seed | $2-5M | Sector - Insurance/Risk Analytics | Catastrophe risk analytics for insurers needs specialized sector playbook | "You provide catastrophe modeling for insurance firms. But can you model YOUR OWN pipeline catastrophes (deals that blow up unexpectedly)? InsureTech and risk analytics have long, technical sales cycles with actuarial evaluation." |
| 35 | **Mindoo** | Seed | $3-8M | Sector - Healthcare IT | AI clinical workflows for healthcare needs healthcare sector playbook | "You automate clinical and administrative tasks with AI. But who's automating YOUR sales tasks? Healthcare IT at Seed stage faces the same HIPAA compliance gates as larger companies - deals die in security review for months." |
| 36 | **Lovable** | Series A | $20-50M | Milestone - Series A/B Scaling | AI coding platform at massive valuation needs scaling playbook | "You're letting users build apps by chatting with AI. But at $6.6B valuation and $330M raise, your board isn't chatting - they're demanding predictable pipeline metrics. Most developer tool companies have engineers running RevOps (wrong skill set)." |
| 37 | **Last Energy** | Growth | $30M+ | Skip - Wrong Sector | Nuclear energy infrastructure (not SaaS) | Skip - Nuclear power, not B2B SaaS |
| 38 | **Radiant Nuclear** | Growth | $50M+ | Skip - Wrong Sector | Nuclear microreactor (not SaaS) | Skip - Nuclear energy, not B2B SaaS |
| 39 | **PolyAI** | Series C+ | $30M+ | TIER 3 - Too Mature | Late-stage voice AI, too mature | Skip - Too late stage |
| 40 | **Cyera** | Series C+ | $50M+ | TIER 3 - Too Mature | Late-stage data security, too mature | Skip - Already analyzed, too late stage |
| 41 | **Mythic** | Series C+ | $30M+ | TIER 3 - Too Mature | AI chip startup, too mature | Skip - Too late stage |
| 42 | **SCALE AI** | Series C+ | $50M+ | TIER 3 - Too Mature | Data labeling platform, too mature | Skip - Too late stage |
| 43 | **Cami** | Unclear | $10-20M | Practitioner - Head of Retail Ops | Retail POS and self-checkout needs retail sector playbook | "You provide POS and analytics for retailers. But how's YOUR point-of-sale (closing deals) analytics? Retail tech companies selling to operations teams often have fragmented pipeline data across regions and store types." |
| 44 | **GravityLabs** | Series A | $8-15M | Milestone - Series A Scaling | Digital transformation and analytics for B2B needs milestone playbook | "You help B2B companies with digital transformation and growth. But at Series A, are YOU digitally transforming your own GTM operations? Consulting/services firms struggle to productize sales - every deal feels like a custom engagement." |
| 45 | **MoEngage** | Growth | $15-30M | Milestone - Series B/C Scaling | Customer engagement platform at scale needs growth-stage playbook | "You orchestrate personalized customer journeys across channels. But at scale, who's orchestrating YOUR sales and marketing journey? Most engagement platforms have internal misalignment - marketing claims credit for pipeline that sales actually sourced." |

---

### BATCH 3: COMPANIES 46-70

| # | Company | Funding | ARR Est. | Playbook Type | Why This Playbook | Outreach Hook |
|---|---------|---------|----------|---------------|-------------------|---------------|
| 46 | **Resolve AI** | Series A | $15-30M | Sector - DevTools/SRE | AI incident response for engineering teams needs DevTools playbook | "You automate incident detection and root-cause analysis for SRE teams. But at $1B valuation, can you detect the root cause of YOUR pipeline incidents? DevTools companies often have engineers managing sales ops - they build great dashboards but can't architect forecast models." |
| 47 | **Galatek** | Series A | $12-20M | Sector - Industrial Manufacturing | Custom manufacturing equipment needs industrial sector playbook | "You deliver custom production machines for manufacturers. But at Series A in industrial sales, how do you forecast which custom deals will close? Manufacturing has 9-12 month sales cycles with complex engineering scoping - traditional CRM doesn't work." |
| 48 | **FINNY** | Series A | $8-15M | Sector - FinTech/Wealth Management | AI prospecting for financial advisors needs FinTech sector playbook | "You use AI to find high-potential prospects for wealth managers. But who's finding YOUR high-potential prospects? FinTech companies selling to advisors have complex compliance and commission-based sales that traditional RevOps can't handle." |
| 49 | **Olea** | Series A | $10-20M | Sector - Retail/Hardware | Kiosk manufacturing for retail/hospitality needs retail hardware playbook | "You manufacture self-service kiosks for retailers and venues. But at Series A selling to enterprises, how do you manage pipeline across different verticals (retail, healthcare, hospitality)? Hardware companies have long lead times and complex project-based sales." |
| 50 | **PowerUp Money** | Series A | $8-15M | Sector - FinTech | Zero-commission mutual fund advisory platform needs FinTech playbook | "You're disrupting wealth management with zero-commission funds. But how are you managing YOUR sales commission structure and forecasting? FinTech platforms often have hybrid B2B2C models that break traditional attribution." |
| 51 | **Chai Discovery** | Series A | $12-20M | Sector - Life Sciences/Biotech | AI drug discovery for pharma needs life sciences playbook | "You use AI to design antibodies and therapeutics for biotech. But who's designing YOUR sales pipeline architecture? Life sciences companies selling to pharma have 12-24 month evaluation cycles with scientific validation - you can't forecast that with generic RevOps." |
| 52 | **Finalis** | Series A | $8-15M | Sector - FinTech/M&A | Financial close and M&A platform for enterprises needs FinTech playbook | "You automate financial reporting and deal materials for M&A teams. But at Series A, who's automating YOUR deal reporting for the board? FinTech companies selling to CFOs and corp dev teams have committee-based buying that stalls deals unpredictably." |
| 53 | **Cordulus** | Series A | $5-10M | Sector - AgTech/IoT | Hyperlocal weather sensors for agriculture needs sector playbook | "You provide hyperlocal weather data for farm operations. But can you predict YOUR OWN sales weather patterns? AgTech and IoT companies have seasonal sales cycles and regional complexity that generic CRMs can't handle." |
| 54 | **Digicust** | Seed | $2-5M | Sector - Logistics/Supply Chain | AI customs automation for freight forwarders needs logistics playbook | "You automate customs declarations with AI for logistics companies. But at Seed stage selling B2B to freight forwarders, who's streamlining YOUR sales process? Logistics tech has fragmented, relationship-driven sales that traditional RevOps misses." |
| 55 | **Smartling** | Series A | $15-30M | Milestone - Series A/B Scaling | Enterprise localization platform at scale needs scaling playbook | "You automate translation workflows for enterprises. But at $15-30M ARR, are YOUR revenue workflows automated? Localization companies selling to global enterprises have multi-region deals with complex procurement - every region has different buying processes." |
| 56 | **Endra** | Seed | $5-12M | Sector - Industrial/Packaging | End-of-line packaging systems for manufacturers needs industrial playbook | "You provide automated packaging and palletizing systems for manufacturers. But who's packaging YOUR pipeline data into board-ready reports? Industrial automation companies have long project-based sales with engineering scoping that takes months." |
| 57 | **Relik** | Seed | Unknown | Skip - Insufficient Data | Unable to determine from available info | Skip - no accessible data |
| 58 | **InfiniteWatch** | Pre-Seed | $2-5M | Skip - Too Early | Mobile app analytics, pre-seed stage | Skip - Pre-seed too early |
| 59 | **Thread** | Growth Equity | $10-20M | Milestone - Growth Stage | AI styling for retail/apparel needs growth-stage playbook | "You provide AI-driven personal styling for retailers. But at growth equity stage, is YOUR GTM well-styled? Fashion tech companies often have consumer-focused teams struggling with B2B enterprise sales." |
| 60 | **Coinbax** | Series A | $8-15M | Sector - FinTech/Crypto | Stablecoin payments for financial institutions needs FinTech playbook | "You provide institutional controls for stablecoin payments. But how controlled is YOUR sales process? FinTech selling to banks and FIs has 9-12 month compliance review cycles that kill pipeline predictability." |
| 61 | **RheumaGen** | Series A | $5-10M | Sector - Life Sciences/Biotech | Precision medicine for rheumatology needs life sciences playbook | "You provide genetics-informed diagnostics for rheumatology. But can you diagnose WHY your pipeline conversion is sick? Life sciences companies selling to healthcare providers have clinical validation cycles that extend sales timelines unpredictably." |
| 62 | **Prokopiak** | Unclear | $5-10M | Practitioner - Head of Marketing | Marketing and brand strategy for B2B/SaaS needs marketing practitioner playbook | "You provide outsourced marketing and demand gen for B2B companies. But who's generating demand for YOUR services? Marketing agencies often have great client ops but broken internal sales ops." |
| 63 | **BatteryStartup/Ample** | Growth | $20M+ | Skip - Wrong Sector | EV battery swapping (not SaaS) | Skip - Hardware/infrastructure, not B2B SaaS |
| 64 | **Ambassador** | Series A | $5-10M | Milestone - Series A Scaling | Referral and partner programs platform needs milestone playbook | "You help companies run referral and affiliate programs. But at $7M Series A, who's helping YOU run a predictable pipeline program? Most martech companies have attribution chaos - they track customer referrals perfectly but can't attribute their own deals." |
| 65 | **Medigate** | Series B+ | $20M+ | TIER 3 - Too Mature | Medical device security, likely late-stage | Skip - Likely too mature |
| 66 | **Meta** | Public | N/A | Skip - Public Company | Meta is public company | Skip - Public company |
| 67 | **Cyphlens** | Seed | $3-8M | Sector - Security/Compliance | Identity-bound encryption for enterprises needs security playbook | "You provide persistent access controls and visual encryption. But at Seed stage selling to enterprise security teams, can you control YOUR pipeline access (visibility)? Security vendors often have long POC cycles with no clear path to purchase." |
| 68 | **Dazzle AI** | Seed | $3-8M | Practitioner - Head of Product/AI | AI product tooling for teams needs product practitioner playbook | "You close the gap between what people want and what they can do with AI. But at Seed stage, are you closing the gap between YOUR demos and closed deals? AI companies often have impressive product demos but undefined sales processes." |
| 69 | **Prance** | Seed | $3-8M | Sector - DevTools/AI Infrastructure | LLM orchestration platform for engineering teams needs DevTools playbook | "You provide production-ready LLM orchestration for product teams. But is YOUR revenue orchestration production-ready? AI infrastructure companies often have engineers managing sales - they can build API integrations but not sales processes." |
| 70 | **Prosperr.io** | Seed | $3-8M | Sector - FinTech/TaxTech | AI tax platform for individuals and enterprises needs FinTech playbook | "You automate tax compliance and planning with AI. But who's planning YOUR sales compliance (forecast accuracy)? FinTech platforms selling to enterprises and consumers simultaneously have attribution nightmares across different buyer journeys." |

---

### BATCH 4: COMPANIES 71-95

| # | Company | Funding | ARR Est. | Playbook Type | Why This Playbook | Outreach Hook |
|---|---------|---------|----------|---------------|-------------------|---------------|
| 71 | **Repsense** | Seed | $2-5M | Practitioner - Head of Marketing/Brand | Marketing and branding services needs marketing practitioner playbook | "You help teams build credible brand identities. But at Seed stage, what's YOUR credibility with pipeline forecasting? Branding agencies struggle with productized sales - every engagement feels custom, every deal unpredictable." |
| 72 | **Zinit** | Seed | $5-10M | Sector - Procurement/Supply Chain | AI procurement platform for enterprises needs sector playbook | "You automate RFP and sourcing for procurement teams. But who's automating YOUR sales sourcing process? Procurement tech selling to category managers has long evaluation cycles with committee-based buying." |
| 73 | **Nodu** | Pre-Seed | $1-3M | Skip - Too Early | Developer tools platform, pre-seed stage | Skip - Pre-seed too early |
| 74 | **Newera.ai** | Seed | $2-5M | Sector - GovTech/Enterprise AI | Production AI systems for government and enterprises needs sector playbook | "You move AI from POC to production in weeks for government and enterprises. But at Seed stage, how long does it take to move YOUR deals from POC to closed contract? GovTech has 6-12 month procurement cycles that traditional CRM can't model." |
| 75 | **Lovable.in** | Series A | $8-15M | Practitioner - Head of Product/Creative | Brand and product design services needs creative practitioner playbook | "You provide end-to-end brand and product design for startups. But at Series A, who's designing YOUR sales experience end-to-end? Design agencies have portfolio-driven sales that don't fit traditional B2B funnels." |
| 76 | **Hyro** | Series C+ | $20M+ | TIER 3 - Too Mature | Conversational AI for healthcare, late-stage | Skip - Series C+ too mature |
| 77 | **Crunchbase** | Series C+ | $30M+ | TIER 3 - Too Mature | Company data platform, too mature | Skip - Too late stage |
| 78 | **Tebra** | Late-Stage | $50M+ | TIER 3 - Too Mature | Practice management platform, too mature | Skip - Already analyzed, too late stage |
| 79 | **CuePilot AI** | Pre-Seed | $3-5M | Practitioner - Head of Product/EdTech | AI learning platform for early childhood education needs EdTech playbook | "You automate planning and assessments for early childhood educators. But at $18M pre-seed selling to schools, who's planning YOUR sales strategy? EdTech has long procurement cycles with school districts that operate on academic calendars, not quarters." |
| 80 | **Naxatra Labs** | Seed | $3-8M | Sector - Hardware/Manufacturing | EV motor production needs industrial/hardware playbook | Skip - Hardware manufacturing, not ideal SaaS fit |
| 81 | **Techloy** | Unclear | $2-5M | Practitioner - Head of Marketing/Growth | Content and growth marketing for tech startups needs marketing playbook | "You help tech startups tell their product story and acquire users. But who's helping YOU tell a predictable revenue story to YOUR stakeholders? Content/growth agencies have project-based revenue that's hard to forecast." |
| 82 | **HoneyBook** | Growth/Series C+ | $20M+ | TIER 3 - Too Mature | Client management for creatives, likely late-stage | Skip - Likely too mature |
| 83 | **NCInnovation** | N/A | N/A | Skip - Domain Broker | Domain name marketplace | Skip - Not a SaaS company |
| 84 | **Gopuff** | Late-Stage | $100M+ | TIER 3 - Too Mature | On-demand delivery, too large | Skip - Too large/late-stage |
| 85 | **Dazzle** | Unclear | $5-10M | Practitioner - Head of Marketing/Commerce | Digital marketing and commerce for consumer brands needs marketing playbook | "You help consumer brands scale digital revenue and acquisition. But at growth stage, who's scaling YOUR revenue predictability? Commerce agencies have client-based revenue that doesn't fit traditional SaaS metrics." |
| 86 | **Nvidia** | Public | N/A | Skip - Public Company | Public company | Skip - Public company |
| 87 | **Erebor** | Series A | $10-20M | Sector - FinTech/Banking | Banking startup with $350M raise needs FinTech playbook | "You're building FDIC-approved banking infrastructure. But at $350M Series A (massive raise), your investors expect institutional-grade revenue operations, not startup-level CRM chaos. FinTech selling financial infrastructure has complex compliance and procurement." |
| 88 | **Radiant** | Growth | $20M+ | Skip - Wrong Sector | Nuclear startup, not SaaS | Skip - Nuclear energy, not B2B SaaS |
| 89 | **Lovable.ai** | Series A | $20-50M | Milestone - Series A Massive Funding | AI code generation at $6.6B valuation needs unicorn-track playbook | "You raised $330M to let people build apps by chatting with AI. But at $6.6B valuation, your board isn't chatting - they want predictable pipeline metrics NOW. Developer tools companies often have engineers managing RevOps (wrong skill set for forecasting)." |
| 90 | **Cami.com** | Unclear | $5-10M | Skip - Insufficient Data | Retail POS, already covered above or insufficient data | Skip - Duplicate or unclear |
| 91 | **Fluency.com** | Series A | $10-20M | Milestone - Series A Scaling | B2B conversational AI platform needs scaling playbook | "You automate conversational engagement for enterprise customers. But at $10-20M ARR after $40M raise, who's managing the CONVERSATION between your sales and marketing teams? AI companies often have attribution chaos - marketing claims 60% source, sales says 20%." |
| 92 | **Echo.com** | Series A | $12-25M | Milestone - Series A/B Scaling | DTC commerce platform needs scaling playbook | "You help DTC brands build stores and subscription revenue. But at Series A with $35M raise, how predictable is YOUR subscription revenue (pipeline)? Commerce companies have great product analytics but terrible sales analytics." |
| 93 | **Ankar.com** | Series A | $8-18M | Practitioner - Head of Product/Services | Digital product services needs productization playbook | "You accelerate product development for companies. But at Series A, who's accelerating YOUR sales development? Product agencies struggle to productize - every engagement feels custom, every forecast is a guess." |
| 94 | **Sequence.com** | Series A | Unknown | Milestone - Series A Scaling | AI revenue agents (if accessible) needs RevOps credibility | "If you're building AI revenue agents, you need pristine revenue operations for credibility. The irony of selling RevOps automation while having broken RevOps is fatal. This is table stakes for trust in the AI GTM space." |
| 95 | **Adaptive-Security.com** | Series B | $15-30M | **TIER 1** - Cybersecurity Series B | Cybersecurity - already have playbook | **ALREADY GENERATED - See TIER1-Adaptive-Security-Playbook.md** |

---

## SUMMARY STATS

**Total Companies Processed:** 95
**Tier 1 (Already Have Deep Playbooks):** 2 (Adaptive Security, Valerie Health)
**Series A Companies:** 45
**Series B Companies:** 3
**Seed/Pre-Seed Companies:** 25 (included for volume)
**Growth/Late-Stage (Tier 3):** 12 (skipped - too mature)
**Skipped (Gov/Non-Profit/Public/Wrong Sector):** 8

---

**PLAYBOOK TYPE BREAKDOWN:**

- **Milestone Playbooks** (Scaling at funding stage): 28 companies
- **Practitioner Playbooks** (Role-specific): 22 companies
- **Sector Playbooks** (Industry-specific): 35 companies
- **Skip/Insufficient Data**: 10 companies

---

## NEXT STEP: GENERATE PERSONALIZED OUTREACH

Now creating individual outreach email for each of the 85 viable companies (95 total - 10 skipped) with their assigned playbook...

