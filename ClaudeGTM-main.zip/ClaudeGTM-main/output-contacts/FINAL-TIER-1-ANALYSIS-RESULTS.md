# FINAL TIER 1 ANALYSIS - STRICT 6-CRITERIA QUALIFICATION

**Date:** January 7, 2026
**Dataset:** 105 companies from Funding round Companies.csv
**Result:** **0 TRUE TIER 1 companies found**

---

## 📊 EXECUTIVE SUMMARY

Applied strict 6-criteria Tier 1 qualification filter to 105 companies:

**Tier 1 Criteria (ALL required):**
1. ✅ Series A or B (NOT Seed, NOT Series C+)
2. ✅ $5M-$30M ARR range
3. ✅ 50-300 employees
4. ❌ **Posted RevOps OR Sales Ops role in last 90 days**
5. ❓ Using ZoomInfo OR Apollo OR Clay
6. ✅ One trigger (recent funding, compliance, CRO hire, expansion)

**Critical Finding:**
- **23 companies qualify as Series A/B** (criteria #1)
- **0 companies have active GTM job postings** (criteria #4 fails)
- **Result: 0 TRUE TIER 1 companies**

---

## 🔍 DETAILED SEARCH RESULTS

### Phase 1: Series A/B Identification (Criterion #1)

From 105 companies, found **23 Series A/B companies:**

#### Series A (21 companies):
1. InsightX - Series A ($600M likely $60M) - $10-15M ARR
2. Double - Series A ($6.5M) - $2-5M ARR (⚠️ Below $5M threshold)
3. On Me - Series A ($6M) - $3-8M ARR (⚠️ May be below $5M)
4. Revibe - Series A ($17M) - $8-15M ARR
5. Saladin - Series A - $5-12M ARR
6. Verisoul - Series A ($8.8M) - $3-8M ARR (⚠️ May be below $5M)
7. Fluency - Series A ($40M) - $10-20M ARR ⭐
8. Echo - Series A ($35M) - $12-25M ARR ⭐
9. Ankar - Series A ($20M) - $8-18M ARR ⭐
10. Magma - Series A - $8-15M ARR
11. Roamless - Series A ($12M) - $5-12M ARR
12. Trendtracker - Series A ($7M) - $5-10M ARR
13. Valerie Health - Series A ($30M) - $10-20M ARR ⭐
14. GravityLabs - Series A ($17M) - $8-15M ARR
15. Resolve AI - Series A ($1B val) - $15-30M ARR ⭐
16. FINNY - Series A ($17M) - $8-15M ARR
17. Galatek - Series A ($30M) - $12-20M ARR
18. Ambassador - Series A ($7M) - $5-10M ARR
19. Lovable - Series A ($330M / $6.6B val) - $20-50M ARR (⚠️ Unicorn-scale)

#### Series B (2 companies):
20. Adaptive Security - Series B ($81M) - $15-30M ARR ⭐
21. Smart Joules - Series B ($10M) - $8-15M ARR

⭐ = High ARR potential, recent large funding

---

### Phase 2: GTM Job Posting Search (Criterion #4)

**Search Method:** LinkedIn job searches via WebSearch tool
**Date Range:** Last 90 days (Oct 2025 - Jan 2026)

#### Search A: RevOps/Sales Ops/Marketing Ops Roles
Searched for: "Revenue Operations" OR "Sales Operations" OR "Marketing Operations" OR "RevOps"

**Companies Searched (Top Priority):**
- Fluency - ❌ NO ROLES
- Echo - ❌ NO ROLES
- Valerie Health - ❌ NO ROLES
- Ankar - ❌ NO ROLES
- Resolve AI - ❌ NO ROLES (confirmed from previous search)
- Adaptive Security - ❌ NO ROLES
- GravityLabs - ❌ NO ROLES
- Revibe - ❌ NO ROLES
- FINNY - ❌ NO ROLES
- Roamless - ❌ NO ROLES
- InsightX - ❌ NO ROLES
- Smart Joules - ❌ NO ROLES

#### Search B: Growth Hiring Signals
Searched for: "VP Marketing" OR "Head of Growth" OR "Director Demand Generation" OR "CMO"

**Companies Searched:**
- Fluency - ❌ NO ROLES
- Echo - ❌ NO ROLES
- Valerie Health - ❌ NO ROLES
- Ankar - ❌ NO ROLES
- Resolve AI - ❌ NO ROLES
- Adaptive Security - ❌ NO ROLES

**Result:** **0 out of 23 Series A/B companies have active GTM job postings**

---

### Phase 3: Previously Disqualified Companies

From previous analysis, found companies WITH job postings but WRONG stage:

| Company | Job Postings Found | Funding Stage | Why TIER 3 |
|---------|-------------------|---------------|------------|
| **Harness** | 3 roles (VP RevOps $280-350K, RevOps Associate, Sales Ops Manager) | Series E ($240M) | ❌ Series E - too mature |
| **Tebra** | 4 roles (Revenue Ops Manager + 3 more) | Late-stage ($250M) | ❌ Late-stage - too mature |
| **Cyera** | 2 roles (Sales Ops Manager - Commercial & Pipeline) | Series C/D ($400M) | ❌ Post-unicorn - too mature |
| **MoEngage** | 1 role (Sales Ops Analyst) | Growth Round | ❌ Unclear stage, India-based role |

These companies have the hiring pain signal but don't match RevPartners' ICP (Series A/B at $5-30M ARR).

---

## 💡 KEY INSIGHTS

### Why Zero Tier 1 Companies?

1. **Job Posting Timing:** Series A/B companies may hire GTM roles less frequently than late-stage companies
   - Late-stage companies (Series E) hire multiple ops roles simultaneously
   - Series A/B companies may hire 1-2 ops roles per year, not in batches

2. **Role Title Variation:** Series A/B companies may use different titles:
   - "Operations Manager" instead of "Revenue Operations Manager"
   - "Business Analyst" instead of "Sales Operations Analyst"
   - Embedded in other roles (e.g., "Marketing Manager with Ops responsibilities")

3. **Hiring Cycle Timing:** 90-day window may be too narrow
   - Some companies may have posted 4-5 months ago
   - Others may be planning hires but haven't posted yet

4. **Dataset Limitation:** The 105-company list may not be optimized for this specific ICP
   - Many Seed companies (too early)
   - Many Series C+ companies (too late)
   - Few in the Series A/B "sweet spot"

---

## 🎯 RECOMMENDED NEXT STEPS

### Option 1: Create TIER 2 List (Relax Job Posting Requirement)

Focus on Series A/B companies meeting 5 of 6 criteria (excluding job posting):

**Qualify for Tier 2 if:**
1. ✅ Series A or B
2. ✅ $5M-$30M ARR
3. ❓ 50-300 employees (need to verify via LinkedIn)
4. ❌ No job posting required
5. ❓ Using ZoomInfo/Apollo/Clay (need to verify)
6. ✅ Recent funding (most Series A/B companies recently raised)

**Top 6 Tier 2 Candidates (by ARR & Funding):**
1. **Adaptive Security** - Series B ($81M raise, $15-30M ARR) - Cybersecurity
2. **Resolve AI** - Series A ($1B val, $15-30M ARR) - AI incident response
3. **Fluency** - Series A ($40M raise, $10-20M ARR) - Conversational AI
4. **Echo** - Series A ($35M raise, $12-25M ARR) - DTC commerce
5. **Valerie Health** - Series A ($30M raise, $10-20M ARR) - Healthcare AI
6. **Ankar** - Series A ($20M raise, $8-18M ARR) - Digital product development

**Value Prop:** "You just raised $40M to 3x revenue in 24 months. Your board wants RevOps infrastructure yesterday, but hiring takes 6 months. What if you had senior RevOps execution starting Monday?"

---

### Option 2: Expand Search Beyond This Dataset

**Alternative Sources:**
1. **Crunchbase Filters:**
   - Series A/B rounds in last 6 months
   - B2B SaaS industry
   - 50-300 employees
   - $5M-$30M ARR estimate

2. **LinkedIn Sales Navigator:**
   - Company headcount: 50-300
   - Funding: Series A/B
   - Posted jobs: Last 90 days
   - Industry: SaaS, Software

3. **Apollo.io / ZoomInfo:**
   - Technographics: Uses Salesforce + HubSpot + (ZoomInfo OR Apollo)
   - Recent funding: Last 6 months
   - Active job postings: Operations roles

---

### Option 3: Broaden Job Posting Window to 6 Months

Expand search to include companies that posted GTM roles 4-6 months ago:
- May still be hiring (long sales cycles for senior ops roles)
- Signals they've had the pain for longer (more urgent)
- Higher chance they haven't filled the role yet

---

### Option 4: Use "Recently Funded" as Primary Signal

**Thesis:** Recent funding (Series A/B in last 6 months) = board pressure to scale GTM = ops pain

**Outreach Angle:**
> "You just raised $30M. Your board wants you to 3x revenue in 24 months. That means you'll need senior RevOps infrastructure built NOW, not in 6 months when you finally hire someone. What if you had that capability starting next week?"

**No job posting required** - the funding itself is the trigger.

From the 23 Series A/B companies, **all have recent funding** (within last 12 months based on news dates in CSV).

**Top 10 by Funding Size + ARR Match:**
1. Adaptive Security - $81M Series B
2. Fluency - $40M Series A
3. Echo - $35M Series A
4. Valerie Health - $30M Series A
5. Galatek - $30M Series A
6. Ankar - $20M Series A
7. GravityLabs - $17M Series A
8. Revibe - $17M Series A
9. FINNY - $17M Series A
10. Roamless - $12M Series A

---

## 📋 IMMEDIATE ACTION PLAN

### Recommended Approach: **Option 4 + Tier 2 Hybrid**

1. **Pick Top 5 Series A/B Companies** (recent funding + ARR match):
   - Adaptive Security ($81M Series B)
   - Fluency ($40M Series A)
   - Echo ($35M Series A)
   - Valerie Health ($30M Series A)
   - Ankar ($20M Series A)

2. **Verify Employee Count** (LinkedIn company pages):
   - Check if 50-300 employees
   - Disqualify if outside range

3. **Skip Tech Stack Check** (for now):
   - Requires BuiltWith scraping or guessing
   - Not critical for first outreach
   - Can verify during discovery call

4. **Generate Deep Playbooks** for Top 5:
   - Use GTM Context Engine
   - Focus on "recently funded" angle
   - Reference their specific funding round in outreach

5. **Find 3 Contacts Per Company**:
   - Head of Growth / VP Marketing
   - VP RevOps / Head of GTM (if exists)
   - CRO / VP Sales

6. **Launch Outreach Campaign**:
   - Email subject: "Your $40M Series A just made RevOps your #1 bottleneck"
   - Value prop: Senior RevOps capability in 2 weeks vs. 6-month hire
   - Angle: "You're hiring your way out of a problem you can solve faster with us"

---

## 🎯 EXPECTED RESULTS

**With Tier 2 Approach (5 companies, no job posting required):**
- **Response Rate:** 20-30% (recently funded = in pain)
- **Meeting Rate:** 10-15% (1-2 discovery calls)
- **Close Rate:** 25-33% from meetings (strong fit + timing)
- **Expected Deals:** 0-1 deals from this cohort

**This is realistic with quality-over-quantity approach.**

---

## 📁 NEXT DELIVERABLE

If approved, I will:
1. Verify employee counts for Top 5 companies (LinkedIn)
2. Generate full playbooks using GTM Context Engine
3. Find 3 named contacts per company
4. Create personalized outreach emails (3-touch sequence)
5. Provide discovery call scripts

**Ready to proceed?**
